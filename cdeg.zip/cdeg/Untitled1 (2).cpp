#include <iostream>
#include <vector>

using namespace std;

struct TestCase {
    int caseNumber;
    long long maxSum;
    int minMoves;
};

// Function to find the maximum consecutive subarray sum
long long maxConsecutiveSubarraySum(const vector<int>& arr) {
    long long maxEndingHere = arr[0];
    long long maxSoFar = arr[0];

    for (size_t i = 1; i < arr.size(); ++i) {
        maxEndingHere = max((long long)arr[i], maxEndingHere + arr[i]);
        maxSoFar = max(maxSoFar, maxEndingHere);
    }

    return maxSoFar;
}

// Function to solve the problem for a single test case
TestCase solveTestCase() {
    int N;
    cin >> N;
    vector<int> arr(N);
    for (int i = 0; i < N; ++i)
        cin >> arr[i];

    long long maxSum = maxConsecutiveSubarraySum(arr);
    int minMoves = 0;

    for (int i = 0; i < N - 1; ++i) {
        for (int j = i + 1; j < N; ++j) {
            // Reverse the subarray from index i to j
            reverse(arr.begin() + i, arr.begin() + j + 1);
            // Calculate the maximum consecutive subarray sum after reversal
            maxSum = max(maxSum, maxConsecutiveSubarraySum(arr));
            // Reverse the subarray back to its original order
            reverse(arr.begin() + i, arr.begin() + j + 1);
        }
    }

    return {N, maxSum, minMoves};
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;

    for (int i = 1; i <= T; ++i) {
        auto result = solveTestCase();
        cout << "Case " << result.caseNumber << ": " << result.maxSum << " " << result.minMoves << "\n";
    }

    return 0;
}
