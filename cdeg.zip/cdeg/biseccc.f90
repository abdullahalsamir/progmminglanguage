program BisectionMethod
   implicit none
   real::a,b,c,fa,fb,fc,tol
   integer::i,max_iter
   write(*,*)"Enter the value of a,b,tolerance,max iteration"
   read(*,*)a,b,tol,max_iter
   fa=f(a);
   fb=f(b)
   if(fa*fb>0.0)Stop "No root in the interval"
   write(*,*)
   write(*,"(a10,5a20)")"Iteration","a","b","c","fc","Tolerance"
   write(*,*)repeat("-",110)

   do i=1,max_iter
    c=a+(b-a)/2.0
    fc=f(c)
    write(*,"(i10,5f20.4)")i,a,b,c,fc,abs(b-a)/2.0
    if(fc==0.0.or.abs(b-a)/2.0<tol)stop
    if(fa*fc>0.0)then
        a=c;fa=fc
        else
            b=c
    end if
   end do
   write(*,*)"Approximate value at x=",c
   contains
   real function f(x)
   real,intent(in)::x
   f=cos(x)-x
   end function f
end program
