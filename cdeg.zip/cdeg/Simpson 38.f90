program simpson38
    implicit none
    real:: a,b,h,sum,x
    integer::i,n
    print*,'Enter a,b and number of subinterval n'
    read*,a,b,n
    if(mod(n,3)/=0) then
        print*,'Number of sub interval must be multiple of 3:'
        stop
        end if
        h=(b-a)/n
        sum=0.0
        do i=0,n-1,3
            sum=sum+(3*h/8)*(f(a+i*h)+3*f(a+(i+1)*h)+3*f(a+(i+2)*h)+f(a+(i+3)*h))
        end do
        print*,'Approximation of the integral is:',sum
        contains
        real function f(x)
        real, intent(in)::x
        f=x**2
        end function f

end program
