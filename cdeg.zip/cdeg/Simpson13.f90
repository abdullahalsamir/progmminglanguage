program Simpson13
    implicit none
    real::a,b,h,sum,x,sum_odd,sum_even
    integer::i,n
    print*,'Enter the value of a,b and subinterval n:'
    read*,a,b,n
    h=(b-a)/n
    sum_odd=0.0
    sum_even=0.0
    do i=1,n-1
        x=a+i*h
        if(mod(i,2)==1)then
            sum_odd=sum_odd+f(x)
            else
                sum_even=sum_even+f(x)
        end if
    end do
    sum=(f(a)+f(b)+4*sum_odd+2*sum_even)*h/3.0
    print*,'Approximation of integral is',sum
    contains
    real function f(x)
    real,intent (in)::x
    f=x**3
    end function f



end program
