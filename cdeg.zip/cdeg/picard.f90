program picardMethod
    implicit none
    real::x,x_end,step,y_i
    integer::n,i,max_iter
    x_end=1.0
    step=0.1
    max_iter=3
    write(*,*)
    write(*,*)"Iteration     | x  |   y_i(x)"
    write(*,*)repeat("-",60)
    do n=1,max_iter
        do i=0,int(x_end/step)
            x=real(i)*step
            if(n==1)then
                y_i=1+x
                else if(n==2)then
                    y_i=1+x+x**2+(x**3)/3.0
                    else if(n==3)then
                        y_i=1+x+x**2+x**3+(2.0/3.0)*x**4+(1.0/3.0)*x**5+(1.0/9.0)*x**6+(1.0/63.0)*x**7
                        end if
                        write(*,"(I9,F7.1,F15.8)")n,x,y_i

        end do
          write(*,*)repeat("-",60)
    end do
end program
