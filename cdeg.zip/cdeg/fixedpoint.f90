program FixedPoint
    implicit none
    real::x0,x1,epsilon
    integer:: iter,max_iter
    print*,'Enter initial guess,tolerance,max_iteration:'
    read*,x0,epsilon,max_iter
    iter=0
    x1=g(x0)
    do while(abs(x1-x0)>epsilon.and.iter<max_iter)
        iter=iter+1
    end do
    print*,'Approximate root at x=',x1
    contains
    real function g(x)
    real,intent(in)::x
    g=sqrt(3.0)
    end function g

end program FixedPoint
