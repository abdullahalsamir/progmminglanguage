program NewtonRaphson
    implicit none
    real::x0,x1,epsilon
    integer::iter,max_iter
    print*,'Enter the initial guess,tolarance,max_iteration'
    read*,x0,epsilon,max_iter
    iter=0
    x1=x0-f(x0)/f_prime(x0)
    do while(abs(x1-x0)>epsilon.and.iter<max_iter)
        x0=x1
        x1=x0-f(x0)/f_prime(x0)
        iter=iter+1

    end do
    print*,'Approximate root at x=',x1
    contains
    real function f(x)
    real,intent(in)::x
    f=x**2-2.0
    end function f
    real function f_prime(x)
    real,intent(in)::x
    f_prime=2.0*x
    end function f_prime

end program NewtonRaphson
