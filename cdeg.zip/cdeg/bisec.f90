program BisectionMethod
    implicit none
    real::a,b,c,fa,fb,fc,epsilon
    integer::iter,max_iter
    print*,'Enter a,b,tolerance,max_iteration:'
    read*,a,b,epsilon,max_iter
    fa=f(a);
    fb=f(b)
    if(fa*fb>0) stop 'No root in[a,b]'
    do while(abs(b-a)>epsilon.and.iter<max_iter)
        c=(a+b)/2.0
        fc=f(c)
        if(fc==0.0)exit
        if(fa*fc<0.0) then
            b=c;fb=fc
          else
            a=c;fa  =fc
        end if
        iter=iter+1
    end do
    print*,'approximate root at x=',c
    contains
    real function f(x)
    real,intent(in)::x
    f=x**3-x-2.0
    end function
    end program

