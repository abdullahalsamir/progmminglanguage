program TrapezoidalRule
    implicit none
    real::a,b,h,sum,x
    integer::i,n
    print*,'Enter the value of a,b and interval n'
    read*,a,b,n
    h=(b-a)/n
    sum=f(a)+f(b)/2
    do i=1,n-1
        x=a+i*h
        sum=sum+f(x)
    end do
    sum=sum*h
    print*,'Approximate of the integral is:',sum
    contains
    real function f(x)
    real,intent(in)::x
    f=x**2
    end function f

end program TrapezoidalRule
