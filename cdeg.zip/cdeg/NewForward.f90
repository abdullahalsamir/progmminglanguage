program backward
    implicit none
    real::x,h,result
    write(*,*)"enter the value of point x and step size(h):"
    read(*,*)x,h
    result =(f(x+h)-f(x-h))/2*h
    write(*,*)"Derivative at x",x,"is",result
    contains
    real function f(x)
    real,intent(in)::x
    f=x**2
    end function f

    end program
