program richard
    implicit none
    real::x,h,result,a_h,a_h2
     integer::k=2
    write(*,*)"enter the approximate point x and initial step size H"
   read(*,*)x,h
    a_h=cdd(x,h)
    a_h2=cdd(x,h/2)
    result=(((2**k)*a_h2)-a_h)/((2**k)-1)
    write(*,*)"Extrapolated Value:",result
    contains
    real function f(x)
    real,intent (in)::x
    f=exp(x)
    end function
    real function cdd(x,h)
    real,intent (in)::x,h
    cdd=(f(x+h)-f(x+h))/2*h
    end function cdd
    end program
