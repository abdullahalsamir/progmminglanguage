program RichardsonExtrapolation
    implicit none
    real::h,x,result,a_h,a_h2
    integer::k=2
    write(*,*)"Enter the approximation point  x and step size h:"
    read(*,*)x,h
    a_h=cdd(x,h)
    a_h2=cdd(x,h/2)
    result=(((2**k)*a_h2)-a_h)/((2**k)-1)
    write(*,*)"Extrapolated value :",result
    contains
    real function f(x)
    real,intent(in)::x
    f=Exp(x)
    end function f

    real function cdd(x,h)
    real,intent(in)::x,h
    cdd=(f(x+h)-f(x-h))/2*h
    end function cdd

end program
