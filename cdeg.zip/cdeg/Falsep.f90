program falsePosition
    implicit none
    real::p0,p,tol
    integer::i,max_iter
    write(*,*)"Enter the value of p0,tolerance,maximum iteration"
    read(*,*) p0,tol,max_iter
    write(*,*)
    write(*,"(a10,3a20)")"Iteration","P0","p","Tolerance"
    write(*,*)repeat("-",100)
    do i=1,max_iter
        if(f_prime(p0)==0)stop "Please enter another initial approximation "
        p=p0-f(p0)/f_prime(p0)
        write(*,"(i10,3f20.4)")i,p0,p,abs(p-p0)
        if(abs(p-p0)<tol)exit
        p0=p
    end do
    write(*,*)"Approximated root at x=",p
    contains
    real function f(x)
    real,intent(in)::x
    f=cos(x)-x
    end function f

    real function f_prime(x)
    real,intent(in)::x
    f_prime=-Sin(x)-1
    end function f_prime




end program
