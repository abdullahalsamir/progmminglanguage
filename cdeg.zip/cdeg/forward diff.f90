program ForwardDiffrence
    implicit none
    real::x,h,f_x,f_xh,derivative
    print*,'Enter x and step size h:'
    read*,x,h
    f_x=f(x)
    f_xh=f(x+h)
    derivative=(f_xh-f_x)/h
    print*,'Approximate derivative at x=',x,'is',derivative

    contains
    real function f(x)
    real,intent(in)::x
    f=x**2
    end function f
end program
