program Simpsons38Rule
implicit none
real :: a, b, h, sum, x
integer :: i, n
print *, 'Enter␣a,␣b,␣and␣number␣of␣subintervals␣n␣(multiple␣of␣3):'
read *, a, b, n
if (mod(n, 3) /= 0) then
print *, 'Number␣of␣subintervals␣must␣be␣a␣multiple␣of␣3.'
stop
end if
h = (b - a) / n
sum = 0.0
do i = 0, n-1, 3
sum = sum + (3*h/8) * (f(a + i*h) + 3*f(a + (i+1)*h) + &
3*f(a + (i+2)*h) + f(a + (i+3)*h))

end do
print *, 'Approximation␣of␣the␣integral␣is:', sum
contains
real function f(x)
real , intent(in) :: x
f = x**2 ! Example function
end function f
end program Simpsons38Rule

