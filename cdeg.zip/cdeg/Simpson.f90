program SimpsonRule
    implicit none
    real::a,b,h,x,sum_odd,sum_even,sum
    integer::i,n

    print*,'Enter the value os a,b and subinterval n:'
    read*,a,b,n
    sum_odd=0.0
    sum_even=0.0
    h=(b-a)/n
    do i=1,n-1
        x=a+i*h
        if(mod(1,2)==1) then
            sum_odd=sum_odd+f(x)
        else
            sum_even=sum_even+f(x)
        end if
    end do
    sum =(f(a)+f(b)+4*sum_odd+2*sum_even)*h/3.0
    print*,'Approximation of integral is:',sum
    contains
    real function f(x)
    real,intent (in)::x
    f=x**3
    end function f

end program SimpsonRule
