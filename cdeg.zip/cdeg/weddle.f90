program weddlerule
    implicit none
    real::a,b,h,sum,x
    integer::i,n
   print*,'Enter the value of a,b and subinterval n:'
    read*,a,b,n
    if(mod(n,6)/=0)then
        print*,'NUmber of sub interval must be multiple of 6'
        stop
    end if
    h=(b-a)/n
    sum=0.0
    do i=0,n-1,6
        sum=sum+3*h/10*(f(a+i*h)+5*f(a+(i+1)*h)+f(a+(i+2)*h)+6*f(a+(i+3)*h)+f(a+(i+4)*h)+5*f(a+(i+5)*h)+f(a+(i+6)*h))

    end do
    print*,'Approximate of the integral is:',sum
    contains
    real function f(x)
    real,intent(in)::x
    f=exp(x)
    end function f
end program
