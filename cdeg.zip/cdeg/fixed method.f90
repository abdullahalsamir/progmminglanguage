program FixedPointIteration
  implicit none
real::x,y,x_new,y_new,tol
integer::i,max_iter
write(*,*)"Enter the value of tolerance and maximum Iteration"
read(*,*)tol,max_iter
write(*,*)"Enter the initial guess"
read(*,*)x,y
write(*,*)
Write(*,*)"Iteration table"
write(*,*)repeat("-",50)
do i=1,max_iter
    x_new=Sqrt(y+3)
    y_new=x+1

    write(*,*)i,x_new,y_new
    if(abs(x_new-x)<tol.and.abs(y_new-y)<tol)then
        write(*,*)"Approximate solution",x_new,y_new
        stop
    end if
    x=x_new
    y=y_new

end do
write(*,*)"Maximum number of iteration exceeded"

end program FixedPointIteration
