program FalsePosition
    implicit none
    real:: a,b,c,fa,fb,fc,tol
    integer::i,max_iter
    write(*,*)"Enter the value of a,b,tolerance"
    read(*,*)a,b,max_iter
    fa=f(a);fb=f(b)
    if(fa*fb>0.0)stop"No root in the interval"


    write(*,*)
    write(*,"(a10, 5a20)")"Iteration","a","b","c","f(c)","Tolerance"
    write(*,*)repeat("-",100)
    do i=1,max_iter
        c=b-fb*(b-a)/(fb-fa)
        fc=f(c)
        write(*,"(i10,5f20.5)")i,a,b,c,fc,abs(c-a)
        if(fb*fc==0.or.abs(c-a)>tol)exit
        if(fb*fc<0.0)then
            a=b,fa=fb
            end if
            b=c;fb=fc


    end do
    write(*,*)"Approximate root at x=",c
    contains
    real function f(x)
    real,intent(in)::x
    f=cos(x)-x
    end function f


end program
