program EulerMethod
    implicit none
    real::a,b,h,x,y
    integer:: n,i
    write(*,*)"enter he value of a,b,h,y(a)"
    read(*,*)a,b,h,y

    write(*,*)
    write(*,*)"Euler's Method"
    write(*,*)repeat("-",50)
    write(*,*)"   step |    x    |    y"
    write(*,*)repeat("-",50)
    n=int((b-a)/h)
    x=a
    do i=1,n
        y=y+h*f(x,y)
        x=a+i*h
        write(*,"(I4,2f12.4)")i,x,y
    end do
    write(*,*)repeat("-",50)
    contains
    real function f(x,y)
    real,intent(in)::x,y
    f=x+y
    end function f
end program
